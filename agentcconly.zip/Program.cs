using System.Diagnostics;
using System.Text;
using Microsoft.CodeAnalysis.CSharp;

// DocsOnlyGuard
//
// Runs entirely locally — no GitHub/CI involved. Verifies that .cs files
// changed relative to a base git ref differ ONLY in comment/whitespace
// trivia (i.e. no code was actually changed), and flags any non-ASCII
// characters introduced into the files. Writes a Markdown report and
// exits 0 (all clear) or 1 (something needs a human look).
//
// Usage (from repo root):
//   dotnet run --project tools/DocsOnlyGuard -- [baseRef] [--report path]
//
// baseRef defaults to HEAD, i.e. it checks your current uncommitted
// working-tree changes. Pass a branch/commit to compare against that
// instead:
//   dotnet run --project tools/DocsOnlyGuard -- main

internal static class Program
{
    private static int Main(string[] args)
    {
        var baseRef = args.FirstOrDefault(a => !a.StartsWith("--")) ?? "HEAD";
        var reportIndex = Array.IndexOf(args, "--report");
        var reportPath = reportIndex >= 0 && reportIndex + 1 < args.Length
            ? args[reportIndex + 1]
            : "docs-verification-report.md";

        var repoRoot = FindRepoRoot(Directory.GetCurrentDirectory());
        if (repoRoot is null)
        {
            Console.Error.WriteLine("ERROR: not inside a git repository.");
            return 2;
        }

        var changedFiles = GetChangedCsFiles(repoRoot, baseRef);
        var results = new List<FileResult>();

        foreach (var relativePath in changedFiles)
        {
            var fullPath = Path.Combine(repoRoot, relativePath);
            var newContent = File.Exists(fullPath) ? File.ReadAllText(fullPath) : null;
            var oldContent = GetFileAtRef(repoRoot, baseRef, relativePath);
            results.Add(EvaluateFile(relativePath, oldContent, newContent));
        }

        WriteReport(reportPath, baseRef, results);

        var failed = results.Where(r => !r.Passed).ToList();
        Console.WriteLine();
        Console.WriteLine(changedFiles.Count == 0
            ? $"No changed .cs files found vs '{baseRef}'."
            : $"DocsOnlyGuard: {results.Count - failed.Count}/{results.Count} files passed.");

        foreach (var f in failed)
            Console.WriteLine($"  FAIL  {f.RelativePath}: {f.Summary}");

        Console.WriteLine($"Report written to {Path.GetFullPath(reportPath)}");
        return failed.Count == 0 ? 0 : 1;
    }

    private static FileResult EvaluateFile(string relativePath, string? oldContent, string? newContent)
    {
        if (newContent is null)
            return new FileResult(relativePath, true, "File deleted — nothing to verify.", []);

        if (oldContent is null)
        {
            var asciiIssuesNew = FindNonAscii(newContent);
            var passedNew = asciiIssuesNew.Count == 0;
            return new FileResult(
                relativePath, passedNew,
                passedNew ? "New file — ASCII OK (not a comment-diff candidate)." : "New file contains non-ASCII characters.",
                asciiIssuesNew);
        }

        var tokensOk = TokensAreEquivalent(oldContent, newContent, out var mismatchDetail);
        var asciiIssues = FindNonAscii(newContent);
        var passed = tokensOk && asciiIssues.Count == 0;

        var summaryParts = new List<string>();
        if (!tokensOk) summaryParts.Add("non-comment code changed");
        if (asciiIssues.Count > 0) summaryParts.Add($"{asciiIssues.Count} non-ASCII character(s) found");

        var detail = new List<string>();
        if (!tokensOk) detail.Add(mismatchDetail);
        detail.AddRange(asciiIssues);

        return new FileResult(
            relativePath, passed,
            passed ? "Comments/doc-comments only. ASCII OK." : string.Join("; ", summaryParts),
            detail);
    }

    // The core check: Roslyn tokens deliberately exclude comment/whitespace
    // trivia — comments are attached TO tokens, they are not tokens
    // themselves. So comparing the token sequence of the old and new file
    // tells us, precisely, whether any actual code changed.
    private static bool TokensAreEquivalent(string oldContent, string newContent, out string mismatchDetail)
    {
        var oldTokens = CSharpSyntaxTree.ParseText(oldContent).GetRoot()
            .DescendantTokens().Select(t => (t.RawKind, t.Text)).ToList();
        var newTokens = CSharpSyntaxTree.ParseText(newContent).GetRoot()
            .DescendantTokens().Select(t => (t.RawKind, t.Text)).ToList();

        if (oldTokens.Count == newTokens.Count && oldTokens.SequenceEqual(newTokens))
        {
            mismatchDetail = string.Empty;
            return true;
        }

        var minLen = Math.Min(oldTokens.Count, newTokens.Count);
        var i = 0;
        while (i < minLen && oldTokens[i] == newTokens[i]) i++;

        var oldSnippet = i < oldTokens.Count ? oldTokens[i].Text : "(end of file)";
        var newSnippet = i < newTokens.Count ? newTokens[i].Text : "(end of file)";
        mismatchDetail =
            $"First code difference at token #{i}: was '{oldSnippet}', now '{newSnippet}' " +
            $"(old had {oldTokens.Count} code tokens, new has {newTokens.Count}).";
        return false;
    }

    private static List<string> FindNonAscii(string content)
    {
        var issues = new List<string>();
        var lines = content.Split('\n');
        for (var lineNum = 0; lineNum < lines.Length; lineNum++)
        {
            foreach (var ch in lines[lineNum])
            {
                if (ch > 127)
                {
                    issues.Add($"Line {lineNum + 1}: non-ASCII character '{ch}' (U+{(int)ch:X4})");
                    break; // one flag per line is enough to point someone at it
                }
            }
        }
        return issues;
    }

    private static List<string> GetChangedCsFiles(string repoRoot, string baseRef)
    {
        var output = RunGit(repoRoot, $"diff --name-only {baseRef} -- \"*.cs\"");
        return output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
    }

    private static string? GetFileAtRef(string repoRoot, string baseRef, string relativePath)
    {
        var (output, exitCode) = RunGitWithExitCode(repoRoot, $"show {baseRef}:\"{relativePath.Replace('\\', '/')}\"");
        return exitCode == 0 ? output : null; // null => file is new since baseRef
    }

    private static string RunGit(string repoRoot, string arguments) => RunGitWithExitCode(repoRoot, arguments).output;

    private static (string output, int exitCode) RunGitWithExitCode(string repoRoot, string arguments)
    {
        var psi = new ProcessStartInfo("git", arguments)
        {
            WorkingDirectory = repoRoot,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
        };
        using var process = Process.Start(psi)!;
        var output = process.StandardOutput.ReadToEnd();
        process.WaitForExit();
        return (output, process.ExitCode);
    }

    private static string? FindRepoRoot(string startDir)
    {
        var dir = new DirectoryInfo(startDir);
        while (dir is not null)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")))
                return dir.FullName;
            dir = dir.Parent;
        }
        return null;
    }

    private static void WriteReport(string path, string baseRef, List<FileResult> results)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Docs-Only Verification Report");
        sb.AppendLine();
        sb.AppendLine($"Compared against: `{baseRef}`  ");
        sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine();

        if (results.Count == 0)
        {
            sb.AppendLine("No changed `.cs` files to verify.");
        }
        else
        {
            var passed = results.Count(r => r.Passed);
            sb.AppendLine($"**Result: {passed}/{results.Count} files passed.**");
            sb.AppendLine();
            sb.AppendLine("| File | Status | Notes |");
            sb.AppendLine("|---|---|---|");
            foreach (var r in results)
                sb.AppendLine($"| `{r.RelativePath}` | {(r.Passed ? "PASS" : "FAIL")} | {r.Summary} |");

            var failed = results.Where(r => !r.Passed).ToList();
            if (failed.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("## Details for failed files");
                foreach (var f in failed)
                {
                    sb.AppendLine();
                    sb.AppendLine($"### `{f.RelativePath}`");
                    foreach (var d in f.Details)
                        sb.AppendLine($"- {d}");
                }
            }
        }

        File.WriteAllText(path, sb.ToString());
    }

    private sealed record FileResult(string RelativePath, bool Passed, string Summary, List<string> Details);
}
