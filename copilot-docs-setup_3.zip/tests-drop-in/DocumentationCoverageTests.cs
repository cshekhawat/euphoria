using System.Diagnostics;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Xunit;

namespace YourProject.Tests.Documentation;

/// <summary>
/// Lets the docs-only Copilot agent verify its own work via the runTests
/// tool instead of a human running the DocsOnlyGuard CLI manually.
///
/// No manually maintained file is required: by default this test
/// determines "the current batch" automatically from
/// <c>git diff --name-only HEAD</c> — i.e. whatever .cs files are
/// currently uncommitted in your working tree. If you want to scope to a
/// specific list instead (e.g. checking files beyond what's currently
/// modified), you can still optionally create
/// tools/DocsOnlyGuard/current-batch.txt (one relative path per line) and
/// it takes priority over the git-diff detection — but it is NOT required
/// for normal use.
///
/// Checks performed (mirrors tools/DocsOnlyGuard's --files logic):
///   1. Presence — does a member have any /// doc comment at all.
///   2. Naive/boilerplate — does the summary just restate the member name.
///   3. Blanket/duplicate — is the exact same summary text reused verbatim
///      across multiple members in this batch (copy-paste smell).
///   4. Structural completeness — Services methods need <remarks>; methods
///      with parameters need <param>; non-void methods need <returns>.
///
/// NOTE: add a PackageReference to Microsoft.CodeAnalysis.CSharp in this
/// test project (same package used by tools/DocsOnlyGuard) for this to
/// compile. Adjust the [Fact] attribute if this project uses NUnit/MSTest
/// instead of xUnit.
/// </summary>
public class DocumentationCoverageTests
{
    private static readonly string RepoRoot = FindRepoRoot(Directory.GetCurrentDirectory())
        ?? throw new InvalidOperationException("Could not locate repo root (.git folder) from test working directory.");

    private static readonly string BatchFilePath = Path.Combine(RepoRoot, "tools", "DocsOnlyGuard", "current-batch.txt");

    [Fact]
    public void CurrentBatch_HasNoDocumentationGaps()
    {
        var relativeFiles = GetBatchFiles();

        if (relativeFiles.Count == 0)
        {
            // Loud, not silent: this shows up in test output so it's never
            // mistaken for "everything passed" — it means nothing was
            // checked at all, which is a different thing entirely.
            Console.WriteLine("DocumentationCoverageTests: no files to check " +
                "(no uncommitted .cs changes found, and no current-batch.txt present).");
            return;
        }

        // Pass 1: collect every summary's text across the batch to detect
        // blanket/copy-pasted duplicates.
        var summaryOccurrences = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var parsedFiles = new Dictionary<string, (SyntaxNode Root, string Layer)>();

        foreach (var relativePath in relativeFiles)
        {
            var fullPath = Path.Combine(RepoRoot, relativePath);
            if (!File.Exists(fullPath)) continue;

            var root = CSharpSyntaxTree.ParseText(File.ReadAllText(fullPath)).GetRoot();
            parsedFiles[relativePath] = (root, ClassifyLayer(relativePath));

            foreach (var node in GetDocCandidates(root))
            {
                if (!IsPublicOrInternal(node)) continue;
                var summary = ExtractSummaryText(node);
                if (string.IsNullOrWhiteSpace(summary) || summary.Length < 8) continue;
                summaryOccurrences[summary] = summaryOccurrences.GetValueOrDefault(summary) + 1;
            }
        }

        // Pass 2: evaluate every member.
        var failures = new StringBuilder();
        var totalGaps = 0;

        foreach (var relativePath in relativeFiles)
        {
            if (!parsedFiles.TryGetValue(relativePath, out var parsed))
            {
                failures.AppendLine($"{relativePath}: FILE NOT FOUND");
                totalGaps++;
                continue;
            }

            var fileFailures = new List<string>();
            foreach (var node in GetDocCandidates(parsed.Root))
            {
                if (!IsPublicOrInternal(node)) continue;

                var reason = AnalyzeDocQuality(node, parsed.Layer, summaryOccurrences);
                if (reason is null) continue;

                var line = node.GetLocation().GetLineSpan().StartLinePosition.Line + 1;
                var (kind, name) = DescribeMember(node);
                fileFailures.Add($"    line {line}: {kind} '{name}' — {reason}");
                totalGaps++;
            }

            if (fileFailures.Count > 0)
            {
                failures.AppendLine($"{relativePath}:");
                foreach (var f in fileFailures) failures.AppendLine(f);
            }
        }

        Assert.True(totalGaps == 0,
            $"\n{totalGaps} member(s) across {relativeFiles.Count} file(s) in the current batch " +
            $"need attention:\n\n{failures}\n" +
            "For MISSING items, add a comment. For anything else, REWRITE the existing comment — " +
            "it does not meet the standard. Fix only these, then re-run this test.");
    }

    private static List<string> GetBatchFiles()
    {
        // Explicit file, if present, always wins — lets you scope beyond
        // what's currently uncommitted if you ever need to.
        if (File.Exists(BatchFilePath))
        {
            var explicitList = File.ReadAllLines(BatchFilePath)
                .Select(l => l.Trim())
                .Where(l => l.Length > 0 && !l.StartsWith('#'))
                .ToList();
            if (explicitList.Count > 0) return explicitList;
        }

        // Default: whatever .cs files are currently uncommitted, per git.
        return GetUncommittedCsFiles();
    }

    private static List<string> GetUncommittedCsFiles()
    {
        var psi = new ProcessStartInfo("git", "diff --name-only HEAD -- \"*.cs\"")
        {
            WorkingDirectory = RepoRoot,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
        };

        try
        {
            using var process = Process.Start(psi)!;
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            if (process.ExitCode != 0) return [];

            return output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
        }
        catch
        {
            // git not available in this environment for some reason —
            // fail open to "nothing to check" rather than crashing the
            // whole test run.
            return [];
        }
    }
        root.DescendantNodes().Where(n =>
            n is ClassDeclarationSyntax or RecordDeclarationSyntax or InterfaceDeclarationSyntax
              or MethodDeclarationSyntax or PropertyDeclarationSyntax or ConstructorDeclarationSyntax);

    private static string? AnalyzeDocQuality(SyntaxNode node, string layer, Dictionary<string, int> summaryOccurrences)
    {
        if (!HasXmlDocComment(node))
            return "MISSING — no XML doc comment at all";

        var summary = ExtractSummaryText(node);
        var (_, name) = DescribeMember(node);

        if (string.IsNullOrWhiteSpace(summary))
            return "has a doc comment block but no <summary> content";

        var humanizedName = HumanizeIdentifier(StripParams(name));
        var normalizedSummary = NormalizeForComparison(summary);
        var normalizedName = NormalizeForComparison(humanizedName);

        if (IsBoilerplatePattern(normalizedSummary, normalizedName))
            return $"naive/boilerplate — summary just restates the name (\"{summary.Trim()}\")";

        if (summary.Length >= 8 && summaryOccurrences.GetValueOrDefault(summary) > 1)
            return $"blanket text — identical summary reused across {summaryOccurrences[summary]} members in this batch";

        if (layer == "Services" && node is MethodDeclarationSyntax && !HasXmlElement(node, "remarks"))
            return "Services methods require a <remarks> section with business rules per csharp-docs-services.instructions.md";

        if (node is MethodDeclarationSyntax method)
        {
            var paramCount = method.ParameterList.Parameters.Count;
            var paramTagCount = CountXmlElements(node, "param");
            if (paramCount > 0 && paramTagCount == 0)
                return $"missing <param> tags for {paramCount} parameter(s)";

            var returnsVoid = method.ReturnType is PredefinedTypeSyntax pts && pts.Keyword.Text == "void";
            if (!returnsVoid && !HasXmlElement(node, "returns"))
                return "missing <returns> tag for a non-void method";
        }

        return null;
    }

    private static string ClassifyLayer(string relativePath)
    {
        if (relativePath.Contains("/Controllers/", StringComparison.OrdinalIgnoreCase)) return "Controllers";
        if (relativePath.Contains("/Services/", StringComparison.OrdinalIgnoreCase)) return "Services";
        if (relativePath.Contains("/Models/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Entities/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/DTOs/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Contracts/", StringComparison.OrdinalIgnoreCase)) return "Models/DTOs";
        if (relativePath.Contains("/Helpers/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Utils/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Extensions/", StringComparison.OrdinalIgnoreCase)) return "Helpers";
        return "Other";
    }

    private static bool IsPublicOrInternal(SyntaxNode node)
    {
        var modifiers = node switch { MemberDeclarationSyntax m => m.Modifiers, _ => default };
        if (modifiers.Count == 0) return false;
        return modifiers.Any(m => m.IsKind(SyntaxKind.PublicKeyword) || m.IsKind(SyntaxKind.InternalKeyword));
    }

    private static bool HasXmlDocComment(SyntaxNode node) =>
        node.GetLeadingTrivia().Any(t =>
            t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia) ||
            t.IsKind(SyntaxKind.MultiLineDocumentationCommentTrivia));

    private static string StripParams(string name) => name.Contains('(') ? name[..name.IndexOf('(')] : name;

    private static string HumanizeIdentifier(string identifier)
    {
        var sb = new StringBuilder();
        foreach (var ch in identifier)
        {
            if (char.IsUpper(ch) && sb.Length > 0) sb.Append(' ');
            sb.Append(char.ToLowerInvariant(ch));
        }
        return sb.ToString();
    }

    private static string NormalizeForComparison(string text) =>
        new string(text.ToLowerInvariant().Where(c => char.IsLetterOrDigit(c) || c == ' ').ToArray())
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(w => w is not ("a" or "the" or "an" or "of" or "for" or "to" or "gets" or "sets"
                or "get" or "set" or "or" or "value" or "indicating" or "whether" or "method" or "class"))
            .OrderBy(w => w, StringComparer.Ordinal)
            .Aggregate(new StringBuilder(), (acc, w) => acc.Append(w).Append(' '), acc => acc.ToString().Trim());

    private static bool IsBoilerplatePattern(string normalizedSummary, string normalizedName)
    {
        if (normalizedName.Length == 0) return false;
        var summaryWords = normalizedSummary.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var nameWords = normalizedName.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        if (summaryWords.Count == 0) return true;

        var overlap = summaryWords.Intersect(nameWords).Count();
        var extraWords = summaryWords.Except(nameWords).Count();
        return nameWords.Count > 0 && overlap >= nameWords.Count - 1 && extraWords <= 2;
    }

    private static (string Kind, string Name) DescribeMember(SyntaxNode node) => node switch
    {
        ClassDeclarationSyntax c => ("class", c.Identifier.Text),
        RecordDeclarationSyntax r => ("record", r.Identifier.Text),
        InterfaceDeclarationSyntax i => ("interface", i.Identifier.Text),
        MethodDeclarationSyntax m => ("method", $"{m.Identifier.Text}({string.Join(", ", m.ParameterList.Parameters.Select(p => p.Type?.ToString() ?? "?"))})"),
        PropertyDeclarationSyntax p => ("property", p.Identifier.Text),
        ConstructorDeclarationSyntax ctor => ("constructor", ctor.Identifier.Text),
        _ => ("member", node.ToString().Split('\n')[0].Trim()),
    };

    private static string ExtractSummaryText(SyntaxNode node) => ExtractXmlElementText(node, "summary");

    private static bool HasXmlElement(SyntaxNode node, string elementName) =>
        !string.IsNullOrWhiteSpace(ExtractXmlElementText(node, elementName));

    private static int CountXmlElements(SyntaxNode node, string elementName)
    {
        var trivia = GetDocTrivia(node);
        if (trivia is null) return 0;
        return trivia.Content.OfType<XmlElementSyntax>()
            .Count(e => e.StartTag.Name.LocalName.Text == elementName);
    }

    private static string ExtractXmlElementText(SyntaxNode node, string elementName)
    {
        var trivia = GetDocTrivia(node);
        if (trivia is null) return string.Empty;

        var element = trivia.Content.OfType<XmlElementSyntax>()
            .FirstOrDefault(e => e.StartTag.Name.LocalName.Text == elementName);
        if (element is null) return string.Empty;

        return string.Concat(element.Content
            .OfType<XmlTextSyntax>()
            .SelectMany(t => t.TextTokens)
            .Select(t => t.ValueText));
    }

    private static DocumentationCommentTriviaSyntax? GetDocTrivia(SyntaxNode node) =>
        node.GetLeadingTrivia()
            .Select(t => t.GetStructure())
            .OfType<DocumentationCommentTriviaSyntax>()
            .FirstOrDefault();

    private static string? FindRepoRoot(string startDir)
    {
        var dir = new DirectoryInfo(startDir);
        while (dir is not null)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")))
                return dir.FullName;
            dir = dir.Parent;
        }
        return null;
    }
}
