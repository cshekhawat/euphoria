# Code Documentation Rollout Tracker

Generated from `docs-coverage-report.md` (run the "Docs: Scan coverage"
task to regenerate the source data). Update the Status column as you go —
this file is your source of truth across sessions, since the work spans
more than one sitting.

## How to use this
1. Run **Docs: Scan coverage (whole repo)** once to see the full picture.
2. Fill in the Batch table below, grouping files into batches of **≤15**
   (the `docs-only` agent's hard limit) within each layer.
3. Work one batch at a time: `docs-only` agent → review diffs → `docs-verifier`
   agent (or the Verify task) → commit → update Status here → next batch.
4. Re-run the coverage scan periodically to confirm the undocumented count
   is trending down and nothing regressed.

## Rollout order (recommended)
1. **Controllers** — smallest surface, highest external visibility (this is
   your published API contract), good place to build confidence in the loop.
2. **Services** — highest business/audit value, most narrative work.
3. **Models/DTOs** — mechanical, low risk, can move fast once 1-2 are done.
4. **Helpers** — lowest volume typically, do last.

## Batch tracker

| Batch | Layer | Files (≤15) | Branch | Status | Verified? | Notes |
|---|---|---|---|---|---|---|
| 1 | Controllers | LoanController.cs, CustomerController.cs, ... | `docs/controllers-batch-1` | Not started | — | |
| 2 | Controllers | ... | `docs/controllers-batch-2` | Not started | — | |
| 3 | Services | ... | `docs/services-batch-1` | Not started | — | |
| ... | | | | | | |

**Status values:** `Not started` → `In progress` → `Comments added, pending review` → `Verified` → `Merged`

## Running totals (update after each Scan)

| Date | Total undocumented members | Files with gaps | Notes |
|---|---|---|---|
| YYYY-MM-DD | (from scan report) | (from scan report) | Baseline |
