// DocsOnlyGuard
//
// Runs entirely locally — no GitHub/CI involved. Three modes:
//
//   VERIFY (default): verifies .cs files changed relative to a base git ref
//   differ ONLY in comment/whitespace trivia (no code changed), and flags
//   any NEW non-ASCII character introduced in a comment (pre-existing
//   legacy non-ASCII content in untouched comments is NOT flagged — only
//   comments that are new or changed in this diff are checked). Also
//   checks that no preprocessor directive (#pragma, #nullable, #region,
//   #if/#endif) or the CONTENT of any disabled #if branch changed — these
//   are trivia, same category as comments, and invisible to a plain token
//   comparison, so they're checked separately. Writes
//   docs-verification-report.md.
//     dotnet run --project tools/DocsOnlyGuard -- [baseRef] [--report path]
//
//   SCAN: inventories the whole repo (not a diff) for public members
//   missing XML doc comments, grouped by folder, so you can prioritize
//   which files to document first. Writes docs-coverage-report.md.
//     dotnet run --project tools/DocsOnlyGuard -- --scan [--report path]
//
//   SCAN --all: same as SCAN, but includes EVERY .cs file regardless of
//   current documentation state (not just ones with gaps) — for a full
//   sweep rather than a gap-prioritized one. Also writes a ready-to-use
//   batch plan (docs-batches.md) chunking files into groups of --batch-size
//   (default 15) per layer, so you don't hand-copy filenames into the tracker.
//     dotnet run --project tools/DocsOnlyGuard -- --scan --all [--batch-size 15]
//
//   SCAN --files a.cs,b.cs,...: scope the scan to an explicit file list (a
//   batch you just ran the docs-only agent against). Reports the EXACT
//   missing members by name/line, not just a count — paste the output
//   straight back to the agent as a redo list. Exits 1 if anything is
//   missing, 0 if the batch is genuinely complete. This is the command to
//   run after every batch, and the only thing that should ever mark a
//   batch "Verified" in docs-rollout-tracker.md — never the agent's own
//   summary.
//     dotnet run --project tools/DocsOnlyGuard -- --scan --files Controllers/A.cs,Controllers/B.cs

using System.Diagnostics;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

internal static class Program
{
    private static int Main(string[] args)
    {
        var reportIndex = Array.IndexOf(args, "--report");
        var explicitReportPath = reportIndex >= 0 && reportIndex + 1 < args.Length
            ? args[reportIndex + 1]
            : null;

        var repoRoot = FindRepoRoot(Directory.GetCurrentDirectory());
        if (repoRoot is null)
        {
            Console.Error.WriteLine("ERROR: not inside a git repository.");
            return 2;
        }

        if (args.Contains("--scan"))
        {
            var includeAll = args.Contains("--all");
            var batchSizeIndex = Array.IndexOf(args, "--batch-size");
            var batchSize = batchSizeIndex >= 0 && batchSizeIndex + 1 < args.Length
                && int.TryParse(args[batchSizeIndex + 1], out var bs) ? bs : 15;

            var filesIndex = Array.IndexOf(args, "--files");
            if (filesIndex >= 0 && filesIndex + 1 < args.Length)
            {
                var fileList = args[filesIndex + 1]
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .ToList();
                return RunBatchVerify(repoRoot, fileList, explicitReportPath ?? "docs-batch-verify-report.md");
            }

            return RunScan(repoRoot, explicitReportPath ?? "docs-coverage-report.md", includeAll, batchSize);
        }

        var baseRef = args.FirstOrDefault(a => !a.StartsWith("--")) ?? "HEAD";
        return RunVerify(repoRoot, baseRef, explicitReportPath ?? "docs-verification-report.md");
    }

    // ---------------------------------------------------------------
    // VERIFY MODE — comments-only diff check
    // ---------------------------------------------------------------

    private static int RunVerify(string repoRoot, string baseRef, string reportPath)
    {
        var changedFiles = GetChangedCsFiles(repoRoot, baseRef);
        var results = new List<FileResult>();

        foreach (var relativePath in changedFiles)
        {
            var fullPath = Path.Combine(repoRoot, relativePath);
            var newContent = File.Exists(fullPath) ? File.ReadAllText(fullPath) : null;
            var oldContent = GetFileAtRef(repoRoot, baseRef, relativePath);
            results.Add(EvaluateFile(relativePath, oldContent, newContent));
        }

        WriteVerifyReport(reportPath, baseRef, results);

        var failed = results.Where(r => !r.Passed).ToList();
        Console.WriteLine();
        Console.WriteLine(changedFiles.Count == 0
            ? $"No changed .cs files found vs '{baseRef}'."
            : $"DocsOnlyGuard: {results.Count - failed.Count}/{results.Count} files passed.");

        foreach (var f in failed)
            Console.WriteLine($"  FAIL  {f.RelativePath}: {f.Summary}");

        Console.WriteLine($"Report written to {Path.GetFullPath(reportPath)}");
        return failed.Count == 0 ? 0 : 1;
    }

    private static FileResult EvaluateFile(string relativePath, string? oldContent, string? newContent)
    {
        if (newContent is null)
            return new FileResult(relativePath, true, "File deleted — nothing to verify.", []);

        if (oldContent is null)
        {
            // Brand new file — there's no "old" to compare against, so
            // every comment in it counts as new; scan all of them.
            var asciiIssuesNew = FindNewNonAsciiInComments(string.Empty, newContent);
            var passedNew = asciiIssuesNew.Count == 0;
            return new FileResult(
                relativePath, passedNew,
                passedNew ? "New file — ASCII OK (not a comment-diff candidate)." : "New file's comments contain non-ASCII characters.",
                asciiIssuesNew);
        }

        var tokensOk = TokensAndDirectivesAreEquivalent(oldContent, newContent, out var mismatchDetail);
        var asciiIssues = FindNewNonAsciiInComments(oldContent, newContent);
        var passed = tokensOk && asciiIssues.Count == 0;

        var summaryParts = new List<string>();
        if (!tokensOk) summaryParts.Add("non-comment code changed");
        if (asciiIssues.Count > 0) summaryParts.Add($"{asciiIssues.Count} new non-ASCII character(s) in comments");

        var detail = new List<string>();
        if (!tokensOk) detail.Add(mismatchDetail);
        detail.AddRange(asciiIssues);

        return new FileResult(
            relativePath, passed,
            passed ? "Comments/doc-comments only. ASCII OK." : string.Join("; ", summaryParts),
            detail);
    }

    // Only flags non-ASCII characters in comments that are NEW or CHANGED
    // relative to the old version — never on comments that already existed,
    // untouched, in the old file. This matters because a large legacy
    // codebase will often already have pre-existing non-ASCII content
    // (accented names, typographic quotes, old emoji) in comments the
    // docs-only agent never touched — failing on those would make huge
    // swaths of the repo permanently unpassable for reasons unrelated to
    // what this batch actually did. Non-ASCII inside CODE (not comments)
    // doesn't need separate handling here: if unchanged, the token check
    // already passes it; if changed, the token check already fails it as
    // "non-comment code changed" — a more accurate reason than an ASCII
    // violation, since the real problem there is the unauthorized edit.
    private static List<string> FindNewNonAsciiInComments(string oldContent, string newContent)
    {
        var oldCommentTexts = new HashSet<string>(
            GetCommentTrivia(CSharpSyntaxTree.ParseText(oldContent).GetRoot()).Select(t => t.ToFullString()));

        var issues = new List<string>();
        foreach (var trivia in GetCommentTrivia(CSharpSyntaxTree.ParseText(newContent).GetRoot()))
        {
            var text = trivia.ToFullString();
            if (oldCommentTexts.Contains(text)) continue; // pre-existing, untouched — not our concern

            var baseLine = trivia.GetLocation().GetLineSpan().StartLinePosition.Line;
            issues.AddRange(ScanForNonAsciiWithLineOffset(text, baseLine));
        }
        return issues;
    }

    private static IEnumerable<SyntaxTrivia> GetCommentTrivia(SyntaxNode root) =>
        root.DescendantTrivia(descendIntoTrivia: true).Where(t =>
            t.IsKind(SyntaxKind.SingleLineCommentTrivia) ||
            t.IsKind(SyntaxKind.MultiLineCommentTrivia) ||
            t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia) ||
            t.IsKind(SyntaxKind.MultiLineDocumentationCommentTrivia));

    private static List<string> ScanForNonAsciiWithLineOffset(string text, int baseLineZeroIndexed)
    {
        var issues = new List<string>();
        var lines = text.Split('\n');
        for (var lineOffset = 0; lineOffset < lines.Length; lineOffset++)
        {
            var line = lines[lineOffset];
            for (var i = 0; i < line.Length; i++)
            {
                var ch = line[i];
                if (ch <= 127) continue;

                int codePoint;
                if (char.IsHighSurrogate(ch) && i + 1 < line.Length && char.IsLowSurrogate(line[i + 1]))
                {
                    codePoint = char.ConvertToUtf32(ch, line[i + 1]);
                    i++;
                }
                else
                {
                    codePoint = ch;
                }

                var actualLine = baseLineZeroIndexed + lineOffset + 1;
                issues.Add($"Line {actualLine}: new non-ASCII character in comment (U+{codePoint:X4})");
                break;
            }
        }
        return issues;
    }

    // Roslyn tokens deliberately exclude comment/whitespace trivia — comments
    // are attached TO tokens, they are not tokens themselves. Comparing the
    // token sequence of the old and new file tells us, precisely, whether
    // any actual code changed.
    //
    // BUT: preprocessor directives (#pragma, #nullable, #region, #if/#endif
    // themselves) and the raw text inside a currently-inactive #if branch
    // are ALSO trivia, not tokens — same category as comments, and
    // therefore invisible to the token comparison alone. A change hidden
    // there (e.g. adding #pragma warning disable, or editing code inside
    // an inactive #if DEBUG block) would pass a token-only check. This
    // method closes that gap by separately comparing every directive and
    // disabled-text trivia node between old and new.
    private static bool TokensAndDirectivesAreEquivalent(string oldContent, string newContent, out string mismatchDetail)
    {
        var oldRoot = CSharpSyntaxTree.ParseText(oldContent).GetRoot();
        var newRoot = CSharpSyntaxTree.ParseText(newContent).GetRoot();

        var oldTokens = oldRoot.DescendantTokens().Select(t => (t.RawKind, t.Text)).ToList();
        var newTokens = newRoot.DescendantTokens().Select(t => (t.RawKind, t.Text)).ToList();

        if (oldTokens.Count != newTokens.Count || !oldTokens.SequenceEqual(newTokens))
        {
            var minLen = Math.Min(oldTokens.Count, newTokens.Count);
            var i = 0;
            while (i < minLen && oldTokens[i] == newTokens[i]) i++;

            var oldSnippet = i < oldTokens.Count ? SanitizeForReport(oldTokens[i].Text) : "(end of file)";
            var newSnippet = i < newTokens.Count ? SanitizeForReport(newTokens[i].Text) : "(end of file)";
            mismatchDetail =
                $"First code difference at token #{i}: was '{oldSnippet}', now '{newSnippet}' " +
                $"(old had {oldTokens.Count} code tokens, new has {newTokens.Count}).";
            return false;
        }

        var oldDirectives = GetDirectiveAndDisabledTrivia(oldRoot);
        var newDirectives = GetDirectiveAndDisabledTrivia(newRoot);

        if (oldDirectives.Count != newDirectives.Count || !oldDirectives.SequenceEqual(newDirectives))
        {
            var minLen = Math.Min(oldDirectives.Count, newDirectives.Count);
            var i = 0;
            while (i < minLen && oldDirectives[i] == newDirectives[i]) i++;

            var oldSnippet = i < oldDirectives.Count ? Truncate(SanitizeForReport(oldDirectives[i].Text)) : "(none)";
            var newSnippet = i < newDirectives.Count ? Truncate(SanitizeForReport(newDirectives[i].Text)) : "(none)";
            mismatchDetail =
                $"Preprocessor directive or disabled-branch content changed: was '{oldSnippet}', " +
                $"now '{newSnippet}' (old had {oldDirectives.Count} directive/disabled-text entries, " +
                $"new has {newDirectives.Count}). This is invisible to a plain token comparison — " +
                "likely a #pragma/#nullable/#region/#if edit, or a change inside an inactive #if branch.";
            return false;
        }

        mismatchDetail = string.Empty;
        return true;
    }

    // Walks every trivia node in the tree (including inside structured
    // trivia, which is where directives live) and collects: (a) every
    // preprocessor directive — #pragma, #nullable, #region, #endregion,
    // #if/#elif/#else/#endif, #define/#undef, #line, #error/#warning —
    // and (b) the raw text sitting inside a currently-disabled #if branch.
    // Both are normalized (whitespace collapsed) so pure reformatting of
    // a directive doesn't cause a false mismatch, while any real content
    // change still will.
    private static List<(string Kind, string Text)> GetDirectiveAndDisabledTrivia(SyntaxNode root)
    {
        var results = new List<(string, string)>();
        foreach (var trivia in root.DescendantTrivia(descendIntoTrivia: true))
        {
            if (trivia.IsKind(SyntaxKind.DisabledTextTrivia))
            {
                results.Add(("DisabledText", NormalizeWhitespace(trivia.ToFullString())));
            }
            else if (trivia.HasStructure && trivia.GetStructure() is DirectiveTriviaSyntax directive)
            {
                results.Add((directive.Kind().ToString(), NormalizeWhitespace(directive.ToFullString())));
            }
        }
        return results;
    }

    private static string NormalizeWhitespace(string text) =>
        string.Join(' ', text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));

    private static string Truncate(string text) => text.Length > 80 ? text[..80] + "..." : text;

    // Last-resort safety net: even with the sanitization above, this
    // catches any unforeseen encoding issue so the tool degrades to a
    // clear error message instead of an unhandled-exception crash. The
    // console summary (pass/fail counts) is computed before this runs, so
    // it still prints even if the detailed report file fails to write.
    private static void WriteReportSafely(string path, string content)
    {
        try
        {
            File.WriteAllText(path, content);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"WARNING: failed to write report to {path}: {ex.Message}");
            Console.Error.WriteLine("The pass/fail result above is still valid — only the detailed report file failed to save.");
        }
    }

    // Escapes any character outside printable ASCII into a \uXXXX (or
    // \U0001XXXX for astral-plane) description rather than embedding it
    // raw. Used anywhere report text is built from content pulled out of
    // the .cs file being checked (token text, directive text), since that
    // content is exactly what might contain the non-ASCII characters this
    // tool exists to flag — the report generator must never itself choke
    // on the thing it's reporting.
    private static string SanitizeForReport(string text)
    {
        var sb = new StringBuilder();
        for (var i = 0; i < text.Length; i++)
        {
            var ch = text[i];
            if (ch >= 32 && ch <= 126) { sb.Append(ch); continue; }

            if (char.IsHighSurrogate(ch) && i + 1 < text.Length && char.IsLowSurrogate(text[i + 1]))
            {
                var codePoint = char.ConvertToUtf32(ch, text[i + 1]);
                sb.Append($"\\U{codePoint:X8}");
                i++;
            }
            else
            {
                sb.Append($"\\u{(int)ch:X4}");
            }
        }
        return sb.ToString();
    }

    private static void WriteVerifyReport(string path, string baseRef, List<FileResult> results)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Docs-Only Verification Report");
        sb.AppendLine();
        sb.AppendLine($"Compared against: `{baseRef}`  ");
        sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine();

        if (results.Count == 0)
        {
            sb.AppendLine("No changed `.cs` files to verify.");
        }
        else
        {
            var passed = results.Count(r => r.Passed);
            sb.AppendLine($"**Result: {passed}/{results.Count} files passed.**");
            sb.AppendLine();
            sb.AppendLine("| File | Status | Notes |");
            sb.AppendLine("|---|---|---|");
            foreach (var r in results)
                sb.AppendLine($"| `{r.RelativePath}` | {(r.Passed ? "PASS" : "FAIL")} | {r.Summary} |");

            var failed = results.Where(r => !r.Passed).ToList();
            if (failed.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("## Details for failed files");
                foreach (var f in failed)
                {
                    sb.AppendLine();
                    sb.AppendLine($"### `{f.RelativePath}`");
                    foreach (var d in f.Details)
                        sb.AppendLine($"- {d}");
                }
            }
        }

        WriteReportSafely(path, sb.ToString());
    }

    // ---------------------------------------------------------------
    // BATCH VERIFY MODE — scoped, named-gap re-check after an agent run.
    // This is the mode that should decide whether a batch is "done" —
    // never the agent's own chat summary.
    // ---------------------------------------------------------------

    private static int RunBatchVerify(string repoRoot, List<string> relativeFiles, string reportPath)
    {
        // Pass 1: collect every existing summary's text across the whole
        // batch, so pass 2 can detect blanket/copy-pasted duplicates —
        // a strong signal of naive, low-effort doc generation.
        var summaryOccurrences = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var parsedFiles = new List<(string RelativePath, SyntaxNode Root, string Layer)>();

        foreach (var relativePath in relativeFiles)
        {
            var fullPath = Path.Combine(repoRoot, relativePath);
            if (!File.Exists(fullPath)) continue;
            var content = File.ReadAllText(fullPath);
            var root = CSharpSyntaxTree.ParseText(content).GetRoot();
            parsedFiles.Add((relativePath, root, ClassifyLayer(relativePath)));

            foreach (var node in GetDocCandidates(root))
            {
                if (!IsPublicOrInternal(node)) continue;
                var summary = ExtractSummaryText(node);
                if (string.IsNullOrWhiteSpace(summary) || summary.Length < 8) continue;
                summaryOccurrences[summary] = summaryOccurrences.GetValueOrDefault(summary) + 1;
            }
        }

        // Pass 2: evaluate each member — missing entirely, or present but
        // naive/blanket/structurally incomplete.
        var fileResults = new List<(string RelativePath, List<MemberGap> Gaps, int Total)>();

        foreach (var relativePath in relativeFiles)
        {
            var fullPath = Path.Combine(repoRoot, relativePath);
            if (!File.Exists(fullPath))
            {
                fileResults.Add((relativePath, [new MemberGap("FILE", "NOT FOUND", 0, "file missing")], 0));
                continue;
            }

            var parsed = parsedFiles.FirstOrDefault(f => f.RelativePath == relativePath);
            var layer = parsed.Layer ?? ClassifyLayer(relativePath);
            var root = parsed.Root ?? CSharpSyntaxTree.ParseText(File.ReadAllText(fullPath)).GetRoot();

            var total = 0;
            var gaps = new List<MemberGap>();
            foreach (var node in GetDocCandidates(root))
            {
                if (!IsPublicOrInternal(node)) continue;
                total++;

                var line = node.GetLocation().GetLineSpan().StartLinePosition.Line + 1;
                var (kind, name) = DescribeMember(node);
                var reason = AnalyzeDocQuality(node, layer, summaryOccurrences);
                if (reason is not null)
                    gaps.Add(new MemberGap(kind, name, line, reason));
            }

            fileResults.Add((relativePath, gaps, total));
        }

        var sb = new StringBuilder();
        sb.AppendLine("# Batch Verification Report");
        sb.AppendLine();
        sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine($"Files checked: {fileResults.Count}");
        sb.AppendLine("Checks: presence, naive/boilerplate wording, duplicate summaries across the batch,");
        sb.AppendLine("missing <remarks> on Services, missing <param>/<returns> where applicable.");
        sb.AppendLine();

        var totalGaps = fileResults.Sum(f => f.Gaps.Count);
        var cleanFiles = fileResults.Count(f => f.Gaps.Count == 0);

        if (totalGaps == 0)
        {
            sb.AppendLine("**VERIFIED — every member in every listed file has a substantive doc comment.**");
            sb.AppendLine("This batch may be marked \"Verified\" in docs-rollout-tracker.md.");
        }
        else
        {
            sb.AppendLine($"**NOT VERIFIED — {cleanFiles}/{fileResults.Count} files clean, "
                + $"{totalGaps} member(s) missing or below quality bar.**");
            sb.AppendLine("Do NOT mark this batch \"Verified\" yet. Paste the list below back to the");
            sb.AppendLine("agent as a redo request — for each item, REWRITE the comment properly rather");
            sb.AppendLine("than assuming it's simply missing.");
            sb.AppendLine();
            sb.AppendLine("## Copy this back to the agent:");
            sb.AppendLine();
            sb.AppendLine("```");
            sb.AppendLine("These members need their doc comments written or rewritten — for items marked");
            sb.AppendLine("MISSING, add a comment; for anything else, REPLACE the existing comment, it does");
            sb.AppendLine("not meet the standard. Then re-read each file again to confirm before reporting:");
            foreach (var f in fileResults.Where(f => f.Gaps.Count > 0))
            {
                sb.AppendLine($"- {f.RelativePath}:");
                foreach (var g in f.Gaps)
                    sb.AppendLine($"    - line {g.Line}: {g.Kind} `{g.Name}` — {g.Reason}");
            }
            sb.AppendLine("```");
        }

        sb.AppendLine();
        sb.AppendLine("## Detail");
        sb.AppendLine();
        sb.AppendLine("| File | Status | Checked |");
        sb.AppendLine("|---|---|---|");
        foreach (var f in fileResults)
        {
            var status = f.Gaps.Count == 0 ? "CLEAN" : $"{f.Gaps.Count} issue(s)";
            sb.AppendLine($"| `{f.RelativePath}` | {status} | {f.Total} member(s) |");
        }

        WriteReportSafely(reportPath, sb.ToString());

        Console.WriteLine(totalGaps == 0
            ? $"VERIFIED — {fileResults.Count} files, 0 issues."
            : $"NOT VERIFIED — {totalGaps} issue(s) across {fileResults.Count - cleanFiles} file(s). See {Path.GetFullPath(reportPath)}");

        return totalGaps == 0 ? 0 : 1;
    }

    private static IEnumerable<SyntaxNode> GetDocCandidates(SyntaxNode root) =>
        root.DescendantNodes().Where(n =>
            n is ClassDeclarationSyntax or RecordDeclarationSyntax or InterfaceDeclarationSyntax
              or MethodDeclarationSyntax or PropertyDeclarationSyntax or ConstructorDeclarationSyntax);

    // Returns null if the doc comment is acceptable, or a human-readable
    // reason string if it's missing, naive/boilerplate, or structurally
    // incomplete per the layer's requirements.
    private static string? AnalyzeDocQuality(SyntaxNode node, string layer, Dictionary<string, int> summaryOccurrences)
    {
        if (!HasXmlDocComment(node))
            return "MISSING — no XML doc comment at all";

        var summary = ExtractSummaryText(node);
        var (_, name) = DescribeMember(node);

        if (string.IsNullOrWhiteSpace(summary))
            return "has a doc comment block but no <summary> content";

        // Naive/boilerplate check: does the summary reduce to essentially
        // just the member name reworded? ("Gets the CustomerId" for a
        // property named CustomerId, "Method for GetOrder" for GetOrder()).
        var humanizedName = HumanizeIdentifier(StripParams(name));
        var normalizedSummary = NormalizeForComparison(summary);
        var normalizedName = NormalizeForComparison(humanizedName);

        if (IsBoilerplatePattern(normalizedSummary, normalizedName))
            return $"naive/boilerplate — summary just restates the name (\"{summary.Trim()}\")";

        // Duplicate/blanket check: same summary text reused verbatim across
        // multiple members in this batch is a strong copy-paste signal.
        if (summary.Length >= 8 && summaryOccurrences.GetValueOrDefault(summary) > 1)
            return $"blanket text — identical summary reused across {summaryOccurrences[summary]} members in this batch (\"{summary.Trim()}\")";

        // Layer-specific structural requirements.
        if (layer == "Services" && node is MethodDeclarationSyntax && !HasXmlElement(node, "remarks"))
            return "Services methods require a <remarks> section with business rules per csharp-docs-services.instructions.md";

        if (node is MethodDeclarationSyntax method)
        {
            var paramCount = method.ParameterList.Parameters.Count;
            var paramTagCount = CountXmlElements(node, "param");
            if (paramCount > 0 && paramTagCount == 0)
                return $"missing <param> tags for {paramCount} parameter(s)";

            var returnsVoid = method.ReturnType is PredefinedTypeSyntax pts && pts.Keyword.Text == "void";
            if (!returnsVoid && !HasXmlElement(node, "returns"))
                return "missing <returns> tag for a non-void method";
        }

        return null;
    }

    private static string StripParams(string name) => name.Contains('(') ? name[..name.IndexOf('(')] : name;

    private static string HumanizeIdentifier(string identifier)
    {
        var sb = new StringBuilder();
        foreach (var ch in identifier)
        {
            if (char.IsUpper(ch) && sb.Length > 0) sb.Append(' ');
            sb.Append(char.ToLowerInvariant(ch));
        }
        return sb.ToString();
    }

    private static string NormalizeForComparison(string text) =>
        new string(text.ToLowerInvariant().Where(c => char.IsLetterOrDigit(c) || c == ' ').ToArray())
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(w => w is not ("a" or "the" or "an" or "of" or "for" or "to" or "gets" or "sets"
                or "get" or "set" or "or" or "value" or "indicating" or "whether" or "method" or "class"))
            .OrderBy(w => w, StringComparer.Ordinal)
            .Aggregate(new StringBuilder(), (acc, w) => acc.Append(w).Append(' '), acc => acc.ToString().Trim());

    private static bool IsBoilerplatePattern(string normalizedSummary, string normalizedName)
    {
        if (normalizedName.Length == 0) return false;
        // If, after stripping filler words, the summary's remaining
        // significant words are essentially just the name's words (or a
        // subset), it's not adding information beyond the identifier.
        var summaryWords = normalizedSummary.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var nameWords = normalizedName.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        if (summaryWords.Count == 0) return true;

        var overlap = summaryWords.Intersect(nameWords).Count();
        var extraWords = summaryWords.Except(nameWords).Count();
        // Nearly all summary content is just the name, with 2 or fewer
        // genuinely new words added.
        return nameWords.Count > 0 && overlap >= nameWords.Count - 1 && extraWords <= 2;
    }

    private static string ExtractSummaryText(SyntaxNode node) => ExtractXmlElementText(node, "summary");

    private static bool HasXmlElement(SyntaxNode node, string elementName) =>
        !string.IsNullOrWhiteSpace(ExtractXmlElementText(node, elementName));

    private static int CountXmlElements(SyntaxNode node, string elementName)
    {
        var trivia = GetDocTrivia(node);
        if (trivia is null) return 0;
        return trivia.Content.OfType<XmlElementSyntax>()
            .Count(e => e.StartTag.Name.LocalName.Text == elementName);
    }

    private static string ExtractXmlElementText(SyntaxNode node, string elementName)
    {
        var trivia = GetDocTrivia(node);
        if (trivia is null) return string.Empty;

        var element = trivia.Content.OfType<XmlElementSyntax>()
            .FirstOrDefault(e => e.StartTag.Name.LocalName.Text == elementName);
        if (element is null) return string.Empty;

        return string.Concat(element.Content
            .OfType<XmlTextSyntax>()
            .SelectMany(t => t.TextTokens)
            .Select(t => t.ValueText));
    }

    private static DocumentationCommentTriviaSyntax? GetDocTrivia(SyntaxNode node) =>
        node.GetLeadingTrivia()
            .Select(t => t.GetStructure())
            .OfType<DocumentationCommentTriviaSyntax>()
            .FirstOrDefault();

    private static (string Kind, string Name) DescribeMember(SyntaxNode node) => node switch
    {
        ClassDeclarationSyntax c => ("class", c.Identifier.Text),
        RecordDeclarationSyntax r => ("record", r.Identifier.Text),
        InterfaceDeclarationSyntax i => ("interface", i.Identifier.Text),
        MethodDeclarationSyntax m => ("method", $"{m.Identifier.Text}({string.Join(", ", m.ParameterList.Parameters.Select(p => p.Type?.ToString() ?? "?"))})"),
        PropertyDeclarationSyntax p => ("property", p.Identifier.Text),
        ConstructorDeclarationSyntax ctor => ("constructor", ctor.Identifier.Text),
        _ => ("member", node.ToString().Split('\n')[0].Trim()),
    };

    private sealed record MemberGap(string Kind, string Name, int Line, string Reason);

    private static int RunScan(string repoRoot, string reportPath, bool includeAll, int batchSize)
    {
        var csFiles = Directory.EnumerateFiles(repoRoot, "*.cs", SearchOption.AllDirectories)
            .Where(f => !f.Contains($"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}")
                     && !f.Contains($"{Path.DirectorySeparatorChar}obj{Path.DirectorySeparatorChar}")
                     && !f.EndsWith(".g.cs") && !f.EndsWith(".Designer.cs"))
            .ToList();

        var coverageResults = new List<CoverageResult>();
        foreach (var fullPath in csFiles)
        {
            var relativePath = Path.GetRelativePath(repoRoot, fullPath).Replace('\\', '/');
            var content = File.ReadAllText(fullPath);
            coverageResults.Add(ScanFile(relativePath, content));
        }

        WriteCoverageReport(reportPath, coverageResults, includeAll);

        if (includeAll)
        {
            var batchPath = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(reportPath)) ?? ".", "docs-batches.md");
            WriteBatchPlan(batchPath, coverageResults, batchSize);
            Console.WriteLine($"Batch plan written to {Path.GetFullPath(batchPath)}");
        }

        var totalMissing = coverageResults.Sum(r => r.UndocumentedCount);
        Console.WriteLine($"Scanned {coverageResults.Count} .cs files.");
        Console.WriteLine($"Total undocumented public/internal members: {totalMissing}");
        Console.WriteLine($"Report written to {Path.GetFullPath(reportPath)}");
        return 0;
    }

    private static CoverageResult ScanFile(string relativePath, string content)
    {
        var root = CSharpSyntaxTree.ParseText(content).GetRoot();

        // Public/internal types and members that SHOULD have XML docs,
        // per csharp-general.instructions.md, but don't.
        var candidates = root.DescendantNodes().Where(n =>
            n is ClassDeclarationSyntax or RecordDeclarationSyntax or InterfaceDeclarationSyntax
              or MethodDeclarationSyntax or PropertyDeclarationSyntax or ConstructorDeclarationSyntax);

        var missing = 0;
        var total = 0;
        foreach (var node in candidates)
        {
            if (!IsPublicOrInternal(node)) continue;
            total++;
            if (!HasXmlDocComment(node)) missing++;
        }

        var layer = ClassifyLayer(relativePath);
        return new CoverageResult(relativePath, layer, total, missing);
    }

    private static bool IsPublicOrInternal(SyntaxNode node)
    {
        var modifiers = node switch
        {
            MemberDeclarationSyntax m => m.Modifiers,
            _ => default,
        };
        if (modifiers.Count == 0) return false;
        return modifiers.Any(m => m.IsKind(SyntaxKind.PublicKeyword) || m.IsKind(SyntaxKind.InternalKeyword));
    }

    private static bool HasXmlDocComment(SyntaxNode node)
        => node.GetLeadingTrivia().Any(t =>
            t.IsKind(SyntaxKind.SingleLineDocumentationCommentTrivia) ||
            t.IsKind(SyntaxKind.MultiLineDocumentationCommentTrivia));

    private static string ClassifyLayer(string relativePath)
    {
        if (relativePath.Contains("/Controllers/", StringComparison.OrdinalIgnoreCase)) return "Controllers";
        if (relativePath.Contains("/Services/", StringComparison.OrdinalIgnoreCase)) return "Services";
        if (relativePath.Contains("/Models/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Entities/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/DTOs/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Contracts/", StringComparison.OrdinalIgnoreCase)) return "Models/DTOs";
        if (relativePath.Contains("/Helpers/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Utils/", StringComparison.OrdinalIgnoreCase)
            || relativePath.Contains("/Extensions/", StringComparison.OrdinalIgnoreCase)) return "Helpers";
        return "Other";
    }

    private static void WriteCoverageReport(string path, List<CoverageResult> results, bool includeAll)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Docs Coverage Report");
        sb.AppendLine();
        sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        if (includeAll)
            sb.AppendLine("Mode: full inventory (every file listed, not just gaps).");
        sb.AppendLine();

        var relevant = includeAll ? results : results.Where(r => r.UndocumentedCount > 0).ToList();
        var ordered = relevant.OrderByDescending(r => r.UndocumentedCount).ToList();

        var withGaps = results.Where(r => r.UndocumentedCount > 0).ToList();
        sb.AppendLine($"**{withGaps.Count} of {results.Count} files have undocumented public/internal members "
            + $"({results.Sum(r => r.UndocumentedCount)} members total).**");
        sb.AppendLine();

        foreach (var layer in new[] { "Controllers", "Services", "Models/DTOs", "Helpers", "Other" })
        {
            var layerFiles = ordered.Where(r => r.Layer == layer).ToList();
            if (layerFiles.Count == 0) continue;

            sb.AppendLine($"## {layer} — {layerFiles.Count} files listed, {layerFiles.Sum(f => f.UndocumentedCount)} undocumented members");
            sb.AppendLine();
            sb.AppendLine("| File | Undocumented / Total members |");
            sb.AppendLine("|---|---|");
            foreach (var f in layerFiles)
                sb.AppendLine($"| `{f.RelativePath}` | {f.UndocumentedCount} / {f.TotalMembers} |");
            sb.AppendLine();
        }

        WriteReportSafely(path, sb.ToString());
    }

    // Chunks every file (regardless of current documentation state) into
    // batches of at most batchSize per layer, ready to paste straight into
    // docs-rollout-tracker.md or hand to the docs-only agent directly —
    // for a full sweep rather than a gap-prioritized one.
    private static void WriteBatchPlan(string path, List<CoverageResult> results, int batchSize)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Docs Batch Plan (full sweep)");
        sb.AppendLine();
        sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine($"Batch size: {batchSize} files. Every .cs file is included, regardless of current documentation state.");
        sb.AppendLine();
        sb.AppendLine("Copy each batch's file list into a docs-only agent request, one batch at a time.");
        sb.AppendLine();

        var batchNumber = 1;
        foreach (var layer in new[] { "Controllers", "Services", "Models/DTOs", "Helpers", "Other" })
        {
            var layerFiles = results.Where(r => r.Layer == layer)
                .OrderBy(r => r.RelativePath, StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (layerFiles.Count == 0) continue;

            sb.AppendLine($"## {layer} ({layerFiles.Count} files)");
            sb.AppendLine();

            for (var i = 0; i < layerFiles.Count; i += batchSize)
            {
                var chunk = layerFiles.Skip(i).Take(batchSize).ToList();
                var layerSlug = layer.Replace("/", "-").ToLowerInvariant();
                sb.AppendLine($"### Batch {batchNumber} — branch `docs/{layerSlug}-batch-{(i / batchSize) + 1}` ({chunk.Count} files)");
                foreach (var f in chunk)
                    sb.AppendLine($"- [ ] `{f.RelativePath}`");
                sb.AppendLine();
                batchNumber++;
            }
        }

        WriteReportSafely(path, sb.ToString());
    }

    // ---------------------------------------------------------------
    // Shared helpers
    // ---------------------------------------------------------------

    // Superseded by FindNewNonAsciiInComments — kept removed intentionally.
    // The old blanket full-file scan flagged pre-existing legacy non-ASCII
    // content even when untouched by this batch, which would make any
    // large legacy codebase largely unpassable for unrelated reasons.

    private static List<string> GetChangedCsFiles(string repoRoot, string baseRef)
    {
        var output = RunGit(repoRoot, $"diff --name-only {baseRef} -- \"*.cs\"");
        return output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
    }

    private static string? GetFileAtRef(string repoRoot, string baseRef, string relativePath)
    {
        var (output, exitCode) = RunGitWithExitCode(repoRoot, $"show {baseRef}:\"{relativePath.Replace('\\', '/')}\"");
        return exitCode == 0 ? output : null;
    }

    private static string RunGit(string repoRoot, string arguments) => RunGitWithExitCode(repoRoot, arguments).output;

    private static (string output, int exitCode) RunGitWithExitCode(string repoRoot, string arguments)
    {
        var psi = new ProcessStartInfo("git", arguments)
        {
            WorkingDirectory = repoRoot,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
        };
        using var process = Process.Start(psi)!;
        var output = process.StandardOutput.ReadToEnd();
        process.WaitForExit();
        return (output, process.ExitCode);
    }

    private static string? FindRepoRoot(string startDir)
    {
        var dir = new DirectoryInfo(startDir);
        while (dir is not null)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")))
                return dir.FullName;
            dir = dir.Parent;
        }
        return null;
    }

    private sealed record FileResult(string RelativePath, bool Passed, string Summary, List<string> Details);
    private sealed record CoverageResult(string RelativePath, string Layer, int TotalMembers, int UndocumentedCount);
}
