---
description: 'Backfill layer-appropriate documentation onto existing undocumented C# files — zero tolerance for logic changes'
agent: docs-only
model: Claude Sonnet 4.5
---
Document ${selection} (or the active file) following our layered C# documentation
standard — the applicable rule set is auto-detected from the file's folder via
each instruction file's own `applyTo` glob, and is also explicitly linked here:
[Controllers](../instructions/csharp-docs-controllers.instructions.md) ·
[Services](../instructions/csharp-docs-services.instructions.md) ·
[Models/DTOs](../instructions/csharp-docs-models-dtos.instructions.md) ·
[Helpers](../instructions/csharp-docs-helpers.instructions.md).

# Precondition
If you have working terminal access, verify the working tree is clean and
the branch is named `docs/*` or `copilot/docs-*` before starting. If you
cannot check this, assume the user has already set it up correctly and
proceed without asking.

# Rules for this pass
- **Documentation only, zero tolerance.** Do not change behavior, signatures,
  formatting of code lines, or rename anything — even to fix an obvious bug.
  Report anything you notice; do not fix it here.
- Add missing XML doc comments (`<summary>`, `<param>`, `<returns>`,
  `<exception>`, `<remarks>`) to every public/internal member per the
  layer-specific style. Do not skip a member because it seems obvious —
  a short accurate summary beats no summary. Incomplete coverage of a file
  is a failed pass, not a partial success.
- Verify by re-reading, not from memory: after editing each file, use
  `read_file` to fetch its current content, list every public/internal
  member, and confirm each has a `///` comment in that fresh read. If any
  are missing, fix them and re-read again until a fresh read shows 100%
  coverage — only then move to the next file.
- Report a verified count per file (e.g. "12/12 members documented,
  confirmed by re-reading") — not an unverified impression that the file
  is done.
- If you run out of output space mid-file, say "Continuing — N of M members
  documented" and proceed automatically on your next output — do not stop
  and ask whether to continue.
- For Services specifically: add `// Step N:` phase comments only where a
  method has genuinely distinct phases — don't force it onto short methods.
- Apply the six approved ASCII tags (`WARNING:`, `SECURITY:`,
  `BUSINESS-RULE:`, `INVARIANT:`, `PERF:`, `TODO:`) only where genuinely
  notable — sparingly, one per block, never emoji in source.
- If you cannot infer the business intent of a method from the code alone
  (ambiguous name, no callers, unclear branch condition), leave a
  `<!-- TODO: confirm business intent -->` placeholder and list it in your
  summary at the end rather than guessing.
- Run the test suite via `runTests` after your edits — this pass must be
  zero-risk. If anything fails, that means the diff touched more than
  comments; find it and revert it before reporting completion.
- Before finishing, re-read your own diff line by line and confirm every
  changed line is a comment token. This self-check is mandatory, not optional.
- End with a short summary: files touched, tags applied, and any TODO
  placeholders that need a human to confirm business intent.
