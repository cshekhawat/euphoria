---
description: 'Review a PR/diff against code-review.instructions.md — works from attached files if read tools are unavailable'
agent: pr-reviewer
model: Claude Sonnet 4.5
tools: ['read_file', 'semantic_search']
---
Review the code in this conversation for a pull request, following
[code-review.instructions.md](../instructions/code-review.instructions.md).

**Source of the code to review, in priority order:**
1. If files or a diff are attached to this message, review those.
2. If `${selection}` is set, review that.
3. Otherwise, ask the user to attach the diff or files — do not guess or
   attempt to fetch them yourself.

**Output format** (so it can be pasted straight into a Bitbucket PR comment):

```
## Code Review — [PR/branch name if known]

### Critical
- `path/to/File.cs:42` — [what's wrong] — [why it matters] — [concrete fix]

### High
- ...

### Medium
- ...

### Low
- ...

### Summary
[2-3 sentences: overall assessment, whether you'd merge as-is]
```

Omit any severity section with zero findings — don't print empty headers.
If everything looks solid, say so plainly in the Summary rather than
inventing Low-severity nitpicks to seem thorough.
