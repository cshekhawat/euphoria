---
name: 'C# Inline Docs — Controllers'
description: 'API-contract-focused commenting style for controllers/endpoints'
applyTo: '**/Controllers/**/*.cs'
---
# Controllers: thin, contract-first documentation

Controllers are the API surface, not the logic. Documentation here describes
the **contract**, not the implementation — because implementation belongs in
Services, and if you find yourself writing step-by-step comments in a
controller, that's a signal the logic is in the wrong layer.

## Required XML doc shape for every action method
```csharp
/// <summary>
/// Approves a pending loan application for the given customer.
/// </summary>
/// <remarks>
/// Requires the <c>LoanOfficer</c> or <c>Underwriter</c> role.
/// Idempotent: re-approving an already-approved application returns 200
/// without side effects.
/// </remarks>
/// <param name="applicationId">The unique identifier of the loan application.</param>
/// <param name="request">Approval details including the approving officer's notes.</param>
/// <response code="200">Application approved; returns the updated application.</response>
/// <response code="404">No application exists with the given id.</response>
/// <response code="409">Application is not in a state that can be approved.</response>
[HttpPost("{applicationId}/approve")]
[ProducesResponseType(typeof(LoanApplicationDto), StatusCodes.Status200OK)]
[ProducesResponseType(StatusCodes.Status404NotFound)]
[ProducesResponseType(StatusCodes.Status409Conflict)]
public async Task<IActionResult> ApproveAsync(Guid applicationId, ApproveLoanRequest request)
{
    var result = await _loanService.ApproveAsync(applicationId, request, User);
    return result.ToActionResult();
}
```

## Rules
- `<summary>` = the business capability, phrased for someone reading generated
  API docs who has never seen the code (this becomes your published endpoint
  reference).
- `<remarks>` carries auth/role requirements, idempotency, rate-limit, or
  versioning notes — not implementation detail.
- Every status code you return gets a `<response code="...">` line **and** a
  matching `[ProducesResponseType]` attribute; these two must stay in sync.
- **No `// Step 1 / Step 2` inline comments in controllers.** Controllers
  should be thin enough (validate → delegate to service → map result) that
  step comments are unnecessary. If a controller needs them, move the logic
  to a service.
- One inline comment is acceptable only to explain a genuinely non-obvious
  framework quirk (e.g., why a specific `[FromServices]` override is needed) —
  not business logic.
