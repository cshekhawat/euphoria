---
name: 'C# Inline Docs — Models/DTOs'
description: 'Property-level semantic documentation for domain models and DTOs'
applyTo: '**/Models/**/*.cs,**/Entities/**/*.cs,**/DTOs/**/*.cs,**/Contracts/**/*.cs'
---
# Models & DTOs: semantic, property-level documentation

No business logic lives here, so documentation is about **meaning**: what a
field represents, its unit/format/constraints, and — for DTOs — its role in
the wire contract. No `// Step N` comments in this layer at all.

## Domain models (business meaning + invariants)
```csharp
/// <summary>
/// A customer's loan application and its lifecycle state.
/// </summary>
/// <remarks>
/// Invariant: once <see cref="Status"/> is Approved or Declined, the
/// application is immutable — corrections require a new application, not
/// a mutation of this record (audit requirement).
/// </remarks>
public class LoanApplication
{
    /// <summary>Requested principal amount, in USD, before any fees.</summary>
    public decimal RequestedAmount { get; init; }

    /// <summary>
    /// FICO score at time of application capture. Null until credit pull
    /// completes; do not treat null as zero in scoring logic.
    /// </summary>
    public int? CreditScore { get; private set; }

    /// <summary>Current lifecycle state; see <see cref="ApplicationStatus"/> for the state machine.</summary>
    public ApplicationStatus Status { get; private set; }
}
```

## DTOs (wire contract + mapping source)
```csharp
/// <summary>
/// Response payload for GET /loan-applications/{id}. Maps from
/// <see cref="LoanApplication"/> via <see cref="LoanApplicationMappingProfile"/>.
/// </summary>
/// <remarks>
/// Versioned contract — this is v2. Do not add non-nullable required fields
/// without bumping the API version; existing clients depend on this shape.
/// </remarks>
public class LoanApplicationDto
{
    /// <summary>Requested amount in USD. Never null; defaults to 0 if unset upstream.</summary>
    public decimal RequestedAmount { get; set; }

    /// <summary>
    /// Human-readable status label (not the internal enum name) —
    /// see StatusDisplayMap for the mapping table.
    /// </summary>
    public string StatusDisplay { get; set; } = string.Empty;
}
```

## Rules
- Every property gets a one-line `///` unless the name is fully
  self-explanatory AND there's no unit/nullability/constraint worth calling
  out (e.g., a plain `Id` on an entity base class can be skipped).
- State units, formats, and nullability semantics explicitly — "null until X
  happens" is far more valuable than restating the type.
- For domain models: document invariants and why mutation is restricted
  (`private set`, `init`) where relevant.
- For DTOs: document which domain type it maps from/to and the mapper that
  performs it, plus any API versioning constraints — this is what keeps
  contract-breaking changes visible during review.
- Do not duplicate validation attribute behavior in prose ("must be positive"
  next to `[Range(0, ...)]"` is fine briefly, but don't restate the whole
  attribute set).
