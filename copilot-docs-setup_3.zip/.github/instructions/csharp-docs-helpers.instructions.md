---
name: 'C# Inline Docs — Helpers'
description: 'Algorithm-focused commenting style for stateless helpers/utilities'
applyTo: '**/Helpers/**/*.cs,**/Utils/**/*.cs,**/Utilities/**/*.cs,**/Extensions/**/*.cs'
---
# Helpers & Utilities: algorithmic documentation

Helpers are reused everywhere, so a mistake in understanding them is
expensive — documentation here should make the **contract and edge-case
behavior** unambiguous to a caller who will never read the implementation.

## Required shape
```csharp
/// <summary>
/// Calculates the risk-adjusted interest rate for a loan, blending the base
/// rate with a credit-score-derived premium.
/// </summary>
/// <remarks>
/// Uses a piecewise-linear premium curve rather than a lookup table so the
/// rate changes smoothly across score boundaries (avoids "score cliff"
/// complaints from a step function). O(1) — no loops or allocations.
/// </remarks>
/// <param name="baseRate">Current base rate as a decimal (e.g., 0.0525 for 5.25%).</param>
/// <param name="creditScore">FICO score, expected range 300-850.</param>
/// <returns>The risk-adjusted rate, never below <paramref name="baseRate"/>.</returns>
/// <exception cref="ArgumentOutOfRangeException">
/// Thrown if <paramref name="creditScore"/> is outside 300-850.
/// </exception>
public static decimal CalculateRiskAdjustedRate(decimal baseRate, int creditScore)
{
    if (creditScore is < 300 or > 850)
        throw new ArgumentOutOfRangeException(nameof(creditScore));

    // Premium shrinks linearly as score rises from 300 to 850; clamped at 0
    // so a perfect score never produces a rate below the base rate.
    var premium = Math.Max(0, (850 - creditScore) / 550m * MaxPremium);
    return baseRate + premium;
}
```

## Rules
- `<summary>` states what the function computes/produces, in domain terms.
- `<remarks>` explains **why this algorithm/approach** was chosen over
  alternatives when it's not obvious — performance characteristics
  (Big-O when relevant), why a simpler approach was rejected, known
  limitations.
- Document the full input contract: valid ranges, units, what happens at
  boundaries — helpers are called from many places by people who won't read
  the body.
- Inline `//` comments are for the specific non-obvious lines only (a
  formula, a clamping decision, a magic number's origin) — not a line-by-line
  narration.
- If a helper encodes a business rule (as in the example above) rather than a
  pure technical utility, treat its `<remarks>` with the same rigor as a
  Service method — business helpers get audited too.
