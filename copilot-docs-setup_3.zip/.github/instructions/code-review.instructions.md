---
name: 'Code Review Standards'
description: 'Checklist and severity model for PR/code review, any language'
applyTo: "**"
---
# Code review standards

These apply whenever reviewing a PR, diff, or selection of code — used by
the `pr-review` prompt and the `pr-reviewer` agent. Keep findings specific
and cite file/line; don't restate generic advice.

## What to check, in this order
1. **Correctness** — logic errors, edge cases (empty/null/max values),
   off-by-one, error handling, concurrency/async safety, race conditions.
2. **Security** — hardcoded secrets/PII, injection (SQL/command/XSS),
   missing authN/authZ, unvalidated input, insecure deserialization, unsafe
   logging of sensitive data. See the security rules in the global
   `copilot-instructions.md` — apply them here too.
3. **Design** — single responsibility, coupling, whether the change matches
   existing patterns in the codebase, whether it belongs in this layer
   (Controller/Service/Model — see `.github/instructions/csharp-docs-*.md`
   for what each layer is responsible for).
4. **Tests** — new/changed behavior has test coverage; assertions are
   meaningful, not just "does not throw"; no production code weakened to
   make it testable.
5. **Performance** — N+1 queries, unnecessary allocations, missing
   indexes/caching where the change makes it relevant. Don't flag
   micro-optimizations that don't matter here.
6. **Documentation** — per the C# inline-docs instructions, if this repo
   has them: does new public API have XML doc comments in the required
   style for its layer?

## Severity model
- **Critical** — will cause incorrect behavior, a security hole, or data
  loss in production. Blocks merge.
- **High** — likely bug or meaningful risk, not certain to fire but
  plausible in real usage. Should be fixed before merge.
- **Medium** — design/maintainability concern, not a functional risk.
  Worth fixing, doesn't have to block.
- **Low** — nitpick, style preference, or optional improvement.

## Output discipline
- Every finding cites the specific file and line/method — never a vague
  "consider improving error handling somewhere."
- Explain the "why," not just "this is wrong" — a reviewer that doesn't
  reason is not useful.
- Propose a concrete fix, not just a description of the problem.
- Don't pad the review with praise for things that are simply correct;
  only note something positive if it's a pattern worth the author repeating
  deliberately elsewhere.
- Never edit code as part of a review — a review is read-only by nature.
