---
applyTo: "**"
---
# Project instructions for GitHub Copilot

## What this project is
<!-- One or two sentences: what the system does and who uses it.
     Example: "Loan origination platform for retail banking customers.
     Backend in ASP.NET Core, frontend in React, batch jobs in Python." -->

## Stack
- Backend: C#/.NET 8, ASP.NET Core, EF Core
- Frontend: React + TypeScript
- Services/tooling: Node.js, Python
- Data: <your DB> — <ORM/access pattern>
- Auth: <your auth mechanism, e.g. Azure AD / OAuth2>

## Where the real rules live
Language- and layer-specific conventions are NOT duplicated here — they live in
`.github/instructions/*.instructions.md`, scoped by `applyTo` (Controllers,
Services, Models/DTOs, Helpers, per language). Read those for how to write code.
This file is the small set of things every request needs regardless of layer.

## Security (non-negotiable)
- Never hardcode secrets, credentials, connection strings, or tokens. Read
  config from <your secrets manager> at runtime.
- Never place real customer data or PII in code, comments, tests, or fixtures.
  Use synthetic data only.
- Parameterized queries only; never build SQL/queries by string concatenation.
- Validate and sanitize all external input at trust boundaries.
- Do not suggest `eval`, dynamic code execution, or insecure deserialization.

## Source encoding & comment style (applies to every language in this repo)
- Source files stay plain ASCII. Never insert emoji or other non-ASCII
  characters into code or comments — this includes .cs, .ts, .tsx, .js, .py,
  and every other source file, not just C#.
- Use text tags instead: `WARNING:`, `SECURITY:`, `BUSINESS-RULE:`,
  `INVARIANT:`, `PERF:`, `TODO:` — sparingly, one per comment block, only
  where genuinely notable.
- Reasons this is non-negotiable: non-ASCII/invisible Unicode characters are
  the mechanism behind Trojan Source-class attacks (CVE-2021-42574/42694);
  emoji read ambiguously to screen readers; doc-generation tooling (DocFX)
  does not reliably render emoji shortcodes.
- Icons/emoji are fine in PR descriptions, README files, and commit messages
  — never in committed source code.

## How to build/test/run
<!-- Exact commands — this is the highest-value section for a new contributor
     or an AI agent, and the one most often left out. -->
- Build: `dotnet build`
- Test: `dotnet test`
- Run locally: `<command>`
- Lint/format: `<command>`

## Conventions
- Prefer the smallest change that solves the task; no unrequested refactors
  or scope creep.
- Match existing patterns in nearby files rather than introducing new ones.
- All new code has tests; new public APIs have XML doc comments.
- Ask a clarifying question when requirements are ambiguous rather than
  guessing.
- Commit messages: <your convention, e.g. Conventional Commits>

## What not to do
<!-- The 3-5 things that keep going wrong. Concrete, not generic. -->
- Do not modify `<sensitive area, e.g. billing calculation module>` without
  explicit confirmation.
- Do not add new third-party dependencies without asking first.
- Do not touch generated/vendored code under `<path>`.
