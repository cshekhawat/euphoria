---
description: 'Backfill layer-appropriate documentation onto existing undocumented C# files — zero tolerance for logic changes'
agent: docs-only
model: Claude Sonnet 4.5
tools: ['search/codebase', 'edit', 'runTests']
---
Document ${selection} (or the active file) following our layered C# documentation
standard — the applicable rule set is auto-detected from the file's folder
(`csharp-controllers.instructions.md`, `csharp-services.instructions.md`,
`csharp-models-dtos.instructions.md`, or `csharp-helpers.instructions.md`).

# Precondition (stop if not met)
Confirm `git status` is clean and the current branch is named `docs/*` or
`copilot/docs-*`. If not, tell the user to create one before you continue —
do not run this prompt against `main`/`master`.

# Rules for this pass
- **Documentation only, zero tolerance.** Do not change behavior, signatures,
  formatting of code lines, or rename anything — even to fix an obvious bug.
  Report anything you notice; do not fix it here.
- Add missing XML doc comments (`<summary>`, `<param>`, `<returns>`,
  `<exception>`, `<remarks>`) to every public/internal member per the
  layer-specific style.
- For Services specifically: add `// Step N:` phase comments only where a
  method has genuinely distinct phases — don't force it onto short methods.
- Apply the six approved ASCII tags (`WARNING:`, `SECURITY:`,
  `BUSINESS-RULE:`, `INVARIANT:`, `PERF:`, `TODO:`) only where genuinely
  notable — sparingly, one per block, never emoji in source.
- If you cannot infer the business intent of a method from the code alone
  (ambiguous name, no callers, unclear branch condition), leave a
  `<!-- TODO: confirm business intent -->` placeholder and list it in your
  summary at the end rather than guessing.
- Run the build/tests after your edits — this pass must be zero-risk. If
  anything fails, the diff touched more than comments; find and revert it.
- Before finishing, re-read your own diff line by line and confirm every
  changed line is a comment token. This self-check is mandatory, not optional.
- End with a short summary: files touched, tags applied, and any TODO
  placeholders that need a human to confirm business intent.
