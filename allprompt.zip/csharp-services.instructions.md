---
name: 'C# Service Documentation'
description: 'Narrative, phase-based commenting style for business logic in services'
applyTo: '**/Services/**/*.cs'
---
# Services: narrative, phase-based documentation

Services hold the business logic — this is where documentation should let a
reader understand the **business process**, including the rules and the "why"
behind branches, without reading every line.

## Required XML doc shape for public service methods
```csharp
/// <summary>
/// Evaluates a loan application against credit policy and either approves,
/// declines, or refers it for manual underwriting.
/// </summary>
/// <remarks>
/// Business rules:
/// - Applications under $50,000 with a credit score >= 680 auto-approve.
/// - Applications flagged by fraud screening always route to manual review,
///   regardless of score (Reg B adverse-action timing applies once declined).
/// - Declines must be issued with a reason code mapped to an ECOA-compliant
///   adverse action notice within 30 days (see AdverseActionService).
/// </remarks>
/// <param name="applicationId">The application to evaluate.</param>
/// <param name="context">The authenticated user performing the evaluation.</param>
/// <returns>The evaluation outcome, including decision and reason code.</returns>
/// <exception cref="ApplicationNotFoundException">No application exists with the given id.</exception>
public async Task<LoanDecision> EvaluateAsync(Guid applicationId, ClaimsPrincipal context)
{
    // Step 1: Load the application and confirm it's still in a decisionable state.
    // Applications already approved/declined are immutable to prevent
    // re-scoring after manual intervention.
    var application = await _repository.GetAsync(applicationId)
        ?? throw new ApplicationNotFoundException(applicationId);

    if (!application.IsDecisionable())
        return LoanDecision.NoAction(application.Status);

    // Step 2: Run fraud screening first — a fraud flag overrides every other
    // signal and forces manual review regardless of credit score.
    // SECURITY: fraud signals must be evaluated before any auto-approval path
    // to prevent an approved-then-flagged race condition.
    var fraudResult = await _fraudService.ScreenAsync(application);
    if (fraudResult.IsFlagged)
        return LoanDecision.ReferToManualReview(fraudResult.Reason);

    // Step 3: Apply credit policy thresholds to reach an automated decision.
    // BUSINESS-RULE: threshold values come from CreditPolicyConfig, not
    // hardcoded here, so Risk can update them without a code deploy.
    var decision = _creditPolicy.Evaluate(application);

    // Step 4: Persist the decision and raise a domain event so downstream
    // systems (notifications, reporting, adverse-action workflow) react
    // without this service knowing about them.
    await _repository.SaveDecisionAsync(application, decision);
    await _eventBus.PublishAsync(new LoanDecisionMadeEvent(application.Id, decision));

    return decision;
}
```

## Rules
- `<summary>` states the business outcome the method produces, not "processes
  the application."
- `<remarks>` is where the **business rules live** — this is the section your
  documentation generator should surface prominently, since it's what a
  business analyst or auditor actually wants to read.
- Break method bodies into `// Step N: <business reason for this step>` blocks
  for any method with more than ~2 distinct phases. The comment explains why
  the step exists / why it's ordered where it is — not what the code
  literally does.
- Call out **why a branch exists**, especially for compliance-driven logic
  (regulatory citation, policy reference) — that context is expensive to
  reconstruct later and is exactly what audits ask for.
- Where a step delegates to another service, say so in the comment ("so this
  service doesn't need to know about X") — that's documenting the
  architecture, not just the code.
